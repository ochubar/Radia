**************************************************************************

      Thank you for downloading the Radia magnetostatics software !

**************************************************************************

The following notes relate to the Radia for Wolfram (=Mathematica) on Apple computers with arm64
 architecture, i.e. the apple silicon M computers.

This version of Radia requires:

- Wolfram 14 or later for MacOSX arm64;
- Web Browser - to read HTML files of the Radia documentation.

**************************************************************************

!!! IMPORTANT !!!
To be able to work with Radia, please do the following:

1) Make sure that the Radia package, in particular Radia.exe, init.m, RadiaTopics.nb and RadiaButtons.nb files are located in the "/Applications/Wolfram.app/Contents/AddOns/Applications/Radia" folder of your Wolfram  installation.

The Wolfram app package contents is found by right clicking on the app icon and select "Show Package Contents"

2) Try examples distributed with the Radia package. Run the Mathematica Front-End. Open the "Example#1.nb" file in the "...\Examples" of the Radia folder. Read instructions in the notebook and try to execute the input cell there. If it behaves as described in the instructions, this means that you have successfully installed Radia. Try the examples #2 - #7.

**************************************************************************

It is assumed that, before starting to seriously work with Radia, you have already got some experience of using Wolfram/Mathematica. If not, please spend some time on that.

Use Web Browser to read the Radia documentation. Start by loading the "...Radia/RadiaDoc/RadiaTitle.html" file and then browse through the documentation structure. The information on the primary Radia functions can be found in the Reference Guide. The documentation is also accessible through the Web.

**************************************************************************

Have fun! Let us know your comments, if any.

Authors:

Pascal ELLEAUME
Oleg CHUBAR  (chubar@bnl.gov)
Joel CHAVANNE  (chavanne@esrf.fr)

Dean Hidas (dhidas@bnl.gov) has ported Radia to Mathematica 10 on Linux and MacOSX using Intel CPUs (April 2016).

Erik Wallen (ejwallen@lbl.gov) has ported Radia to Wolfram 14 on MacOSX using Apple M CPUs with arm64 architecture (March 2026).
